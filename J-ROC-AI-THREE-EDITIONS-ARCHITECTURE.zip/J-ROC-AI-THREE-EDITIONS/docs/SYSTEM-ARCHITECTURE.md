# J-ROC AI Full System Architecture

## Shared foundation
All three editions use shared contracts and reusable platform capabilities rather than maintaining three unrelated technology stacks.

### Shared services
- Brand system and product identity
- Identity and authentication contracts
- Permission and entitlement engine
- Application registry and 250-application catalog
- J-ROC AI Hub integration contracts
- J-ROC AI Model Gateway
- Shared document engine for Word, Excel, and PowerPoint exports
- Database and storage contracts
- Audit logging
- Events and notifications
- Shared user interface components
- Release gates

## Edition boundaries
### Private Edition
Owner-only control plane. Provides Chairman Office, software and application factories, business factory, Academy administration, complete application registry, model and worker administration, release administration, and private strategies. It is not sold.

### Business Edition
Customer-facing organization platform for businesses and enterprise customers. Data is tenant-scoped. It provides organization administration, roles, application entitlements, Academy, employee workspace, business applications, billing and licensing surfaces, application programming interface access where entitled, and enterprise controls.

### Consumer Edition
Customer-facing individual platform. It provides account management, application marketplace, owned applications, Academy, tutors, subscriptions, and one-time standalone purchases. It deliberately excludes Chairman controls and factory administration.

## Request path
Client → Edition Shell → Identity → Permission/Entitlement Check → Shared Service or Application → Model Gateway when artificial intelligence is needed → Audit/Event → Response.

## Application distribution
Each application has one canonical implementation and an edition availability policy. Editions control access through entitlements instead of copying the application three times.

## Security boundary
Private services are deployed separately from customer-facing services. Hiding a menu item is never considered authorization. Business tenant context must be verified from authenticated membership. Consumer accounts may access only resources owned by or explicitly shared with that account.

## Document architecture
Applications use one shared export interface for Word, Excel, and PowerPoint output. Export requests pass through authorization, brand resolution, template selection, rendering, output handling, and audit logging.
