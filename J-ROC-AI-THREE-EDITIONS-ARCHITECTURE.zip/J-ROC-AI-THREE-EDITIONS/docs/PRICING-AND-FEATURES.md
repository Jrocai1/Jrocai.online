# J-ROC AI Edition Features and Suggested Launch Pricing

These prices are product-strategy suggestions, not validated market prices or commitments. Test willingness to pay and measure actual artificial intelligence cost per active customer before launch.

## Private Edition
- Owner only
- Not for sale
- Full platform administration
- Chairman Office
- Software Factory and App Factory
- Full business-building agents
- Academy administration
- All approved application access
- Full platform audit and release controls

## Business Edition
### Business Starter — suggested $49/month
- 3 included seats
- Organization workspace
- Business application catalog
- Academy
- Shared Office document export
- Standard audit history
- Standard artificial intelligence allowance

### Business Professional — suggested $149/month
- 10 included seats
- Starter capabilities
- Advanced business applications
- Custom agents
- Workflow automation
- Application programming interface access
- Advanced analytics
- Higher artificial intelligence allowance

### Business Enterprise — custom annual agreement
- Organization-specific commercial terms
- Multiple business units
- Advanced permission and entitlement controls
- Private organizational knowledge
- Managed deployment options
- Enterprise audit capability
- Priority support

## Consumer Edition
### Free — $0/month
- Limited application access
- Limited artificial intelligence allowance
- Academy preview

### Plus — suggested $12/month
- Consumer application catalog
- Academy membership
- Standard artificial intelligence allowance
- Word, Excel, and PowerPoint export where supported

### Premium — suggested $29/month
- Plus capabilities
- Premium applications
- Higher artificial intelligence allowance
- Advanced tutors
- Premium exports

### Standalone applications
Suggested initial test range: $9–$79 one-time depending on application value and ongoing compute requirements.

## Pricing rule
Artificial intelligence has variable compute cost, so commercial launch pricing should measure cost per active customer and use feature, usage, credit, or hybrid limits when necessary.
