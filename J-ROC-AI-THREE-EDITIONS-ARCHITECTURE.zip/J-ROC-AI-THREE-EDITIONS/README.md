# J-ROC AI Three-Edition Architecture

This workspace defines the target project layout for:
1. J-ROC AI Private Edition
2. J-ROC AI Business Edition
3. J-ROC AI Consumer Edition

It is an architecture scaffold, not a claim that the complete three-edition product is implemented or deployed.

Start with `docs/SYSTEM-ARCHITECTURE.md`, `docs/PRICING-AND-FEATURES.md`, and `docs/PROJECT-STRUCTURE.md`.
