$ErrorActionPreference='Stop'
if(-not(Test-Path .env)){Copy-Item .env.example .env}
node src/server.js
