# J-ROC AI Microsoft Agent Team Expanded

This package contains 25 specialist Microsoft Copilot Studio-ready agent definitions plus a multi-agent orchestration map.

Create specialists first, test each independently, then connect only the specialists needed by the Production Build Coordinator or Application Factory workflows.
