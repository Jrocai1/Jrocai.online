# Recommended Copilot Studio tools

Configure only the tools each agent needs:

- Read-only project knowledge from SharePoint or OneDrive.
- Microsoft Planner actions for implementation tasks and release tracking.
- Power Automate flows for approval requests, notifications, and controlled operations.
- Custom connector or HTTP actions for staging-only J-ROC AI endpoints.
- GitHub connector for repository issues, pull requests, and approved workflows when available.

Never connect production secrets directly as agent knowledge. Place consequential actions behind approval flows and least-privilege service identities.
