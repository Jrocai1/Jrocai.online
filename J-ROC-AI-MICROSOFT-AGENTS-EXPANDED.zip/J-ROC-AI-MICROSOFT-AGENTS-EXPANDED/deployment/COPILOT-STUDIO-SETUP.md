# Create the agents in Microsoft Copilot Studio

1. Create a new agent in Microsoft Copilot Studio for each folder under `agents`.
2. Copy the agent name and description from `agent.json`.
3. Copy `INSTRUCTIONS.md` into the agent Instructions section.
4. Add `knowledge/SHARED-RULES.md` and approved J-ROC AI project documents as knowledge.
5. Add only the tools listed for that agent, using least-privilege connections.
6. Test the agent with allow, deny, incomplete-evidence, and escalation scenarios.
7. Publish specialist agents only after tests pass.
8. Create the J-ROC AI Production Build Coordinator last and add the specialist agents for multi-agent routing where supported.
9. Use separate development, testing, and production environments.
10. Require approval before production actions.

## Initial test prompts

- Produce the Production Build 1 implementation plan and assign each workstream.
- Prove that Organization A cannot read Organization B records.
- Review the email verification and recovery design for replay risks.
- Evaluate whether the current build is blocked or release-ready and list evidence.
- Create a rollback plan for the Business Edition deployment.
