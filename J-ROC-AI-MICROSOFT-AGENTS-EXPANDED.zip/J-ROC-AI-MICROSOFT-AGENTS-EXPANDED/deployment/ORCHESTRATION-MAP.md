# J-ROC AI Multi-Agent Orchestration Map

## Parent coordinator
J-ROC AI Production Build Coordinator

## Production Build 1 specialists
Identity and Access → PostgreSQL Tenant Security → Application Programming Interface Security → Security Test → Deployment → Reliability and Recovery → Release Gate.

## Product construction specialists
Application Factory coordinates Software Factory, Web Experience, Windows Application, Office Document, Brand Governance, Model Gateway, Background Worker, Storage and File Security, and Academy and Learning as applicable.

## Commercial platform specialists
Billing and Entitlement works with Marketplace and Licensing. Both must provide evidence to the Release Gate Agent.

## Cross-cutting reviewers
Observability, Privacy and Data Governance, Performance and Capacity, and Database Migration and Release review affected work before release.

Use connected agents only when domain separation is useful. Keep each agent narrowly scoped, pass only necessary context, and do not allow a parent agent to gain privileges through a specialist agent.
