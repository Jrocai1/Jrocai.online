using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using W = DocumentFormat.OpenXml.Wordprocessing;
using S = DocumentFormat.OpenXml.Spreadsheet;
using P = DocumentFormat.OpenXml.Presentation;
using D = DocumentFormat.OpenXml.Drawing;

var output = args.Length > 0 ? args[0] : Path.Combine(Environment.CurrentDirectory, "exports");
Directory.CreateDirectory(output);
WordExporter.Create(Path.Combine(output, "J-ROC-AI-Executive-Report.docx"));
ExcelExporter.Create(Path.Combine(output, "J-ROC-AI-Operations-Workbook.xlsx"));
PowerPointExporter.Create(Path.Combine(output, "J-ROC-AI-Platform-Brief.pptx"));
Console.WriteLine($"Created Office files in {output}");

static class Brand {
  public const string Blue="00B3FF", Graphite="0B0F14", DeepBlue="0071FF", Silver="C0C6D4";
  public const string Name="J-ROC AI", Tagline="ONE BRAND. ONE ECOSYSTEM.";
}
static class WordExporter {
  public static void Create(string path) {
    using var doc=WordprocessingDocument.Create(path,WordprocessingDocumentType.Document);
    var main=doc.AddMainDocumentPart(); main.Document=new W.Document(new W.Body()); var body=main.Document.Body!;
    body.Append(Para(Brand.Name,"36",Brand.DeepBlue,true),Para("Windows Document Export Prototype","24",Brand.Graphite,true),Para(Brand.Tagline,"18",Brand.Silver,false));
    body.Append(new W.Paragraph(new W.Run(new W.Break(){Type=W.BreakValues.Page})));
    body.Append(Para("Executive Summary","24",Brand.DeepBlue,true),Para("This prototype demonstrates a shared Windows document service that creates Microsoft Word, Microsoft Excel, and Microsoft PowerPoint files for J-ROC AI applications.","22",Brand.Graphite,false));
    body.Append(Para("Architecture","24",Brand.DeepBlue,true));
    foreach(var line in new[]{"Application requests an export","Export request is validated","Brand and product metadata are applied","Format-specific renderer creates the document","Output is stored, audited, and returned to the application"}) body.Append(Para("• "+line,"21",Brand.Graphite,false));
    body.Append(Para("Supported Deliverables","24",Brand.DeepBlue,true));
    var table=new W.Table(new W.TableProperties(new W.TableBorders(new W.TopBorder{Val=W.BorderValues.Single,Color=Brand.Silver},new W.BottomBorder{Val=W.BorderValues.Single,Color=Brand.Silver},new W.InsideHorizontalBorder{Val=W.BorderValues.Single,Color=Brand.Silver})));
    foreach(var row in new[]{new[]{"Format","Use"},new[]{"Word","Reports, proposals, plans, documentation"},new[]{"Excel","Inventory, analytics, schedules, financial models"},new[]{"PowerPoint","Briefings, training, proposals, executive presentations"}}){var tr=new W.TableRow();foreach(var v in row)tr.Append(new W.TableCell(Para(v,"20",Brand.Graphite,row==null)));table.Append(tr);} body.Append(table);
    body.Append(Para("Production Controls","24",Brand.DeepBlue,true),Para("Sensitive exports require permission checks, secure temporary storage, audit records, approved branding assets, and explicit approval before external distribution.","22",Brand.Graphite,false));
    main.Document.Save();
  }
  static W.Paragraph Para(string text,string size,string color,bool bold){var rp=new W.RunProperties(new W.Color{Val=color},new W.FontSize{Val=size},new W.RunFonts{Ascii="Arial",HighAnsi="Arial"});if(bold)rp.Append(new W.Bold());return new W.Paragraph(new W.Run(rp,new W.Text(text)));}
}
static class ExcelExporter {
  public static void Create(string path){using var doc=SpreadsheetDocument.Create(path,SpreadsheetDocumentType.Workbook);var wb=doc.AddWorkbookPart();wb.Workbook=new S.Workbook();var ws=wb.AddNewPart<WorksheetPart>();var data=new S.SheetData();ws.Worksheet=new S.Worksheet(data);var sheets=wb.Workbook.AppendChild(new S.Sheets());sheets.Append(new S.Sheet{Id=wb.GetIdOfPart(ws),SheetId=1,Name="Operations"});
    string[][] rows={new[]{Brand.Name,"Operations Workbook",""},new[]{"Application","Delivery","Status"},new[]{"Chairman Office","Both","Planned"},new[]{"Universal Repair Edition","Windows","Planned"},new[]{"Academy","Web","Building"},new[]{"Total Applications","","3"}};
    uint i=1;foreach(var row in rows){var r=new S.Row{RowIndex=i++};foreach(var v in row)r.Append(new S.Cell{DataType=S.CellValues.InlineString,InlineString=new S.InlineString(new S.Text(v))});data.Append(r);}wb.Workbook.Save();}
}
static class PowerPointExporter {
  public static void Create(string path){using var doc=PresentationDocument.Create(path,PresentationDocumentType.Presentation);var pp=doc.AddPresentationPart();pp.Presentation=new P.Presentation();var master=pp.AddNewPart<SlideMasterPart>();master.SlideMaster=new P.SlideMaster(new P.CommonSlideData(new P.ShapeTree(new P.NonVisualGroupShapeProperties(new P.NonVisualDrawingProperties{Id=1,Name=""},new P.NonVisualGroupShapeDrawingProperties(),new P.ApplicationNonVisualDrawingProperties()),new P.GroupShapeProperties(new D.TransformGroup()))),new P.ColorMap{Background1=D.ColorSchemeIndexValues.Light1,Text1=D.ColorSchemeIndexValues.Dark1,Background2=D.ColorSchemeIndexValues.Light2,Text2=D.ColorSchemeIndexValues.Dark2,Accent1=D.ColorSchemeIndexValues.Accent1,Accent2=D.ColorSchemeIndexValues.Accent2,Accent3=D.ColorSchemeIndexValues.Accent3,Accent4=D.ColorSchemeIndexValues.Accent4,Accent5=D.ColorSchemeIndexValues.Accent5,Accent6=D.ColorSchemeIndexValues.Accent6,Hyperlink=D.ColorSchemeIndexValues.Hyperlink,FollowedHyperlink=D.ColorSchemeIndexValues.FollowedHyperlink});var layout=master.AddNewPart<SlideLayoutPart>();layout.SlideLayout=new P.SlideLayout(new P.CommonSlideData(new P.ShapeTree(new P.NonVisualGroupShapeProperties(new P.NonVisualDrawingProperties{Id=1,Name=""},new P.NonVisualGroupShapeDrawingProperties(),new P.ApplicationNonVisualDrawingProperties()),new P.GroupShapeProperties(new D.TransformGroup()))));master.Append(new P.SlideLayoutIdList(new P.SlideLayoutId{Id=1,RelationshipId=master.GetIdOfPart(layout)}));master.SlideMaster.Append(new P.TextStyles());var slide=pp.AddNewPart<SlidePart>();slide.AddPart(layout);slide.Slide=new P.Slide(new P.CommonSlideData(new P.ShapeTree(new P.NonVisualGroupShapeProperties(new P.NonVisualDrawingProperties{Id=1,Name=""},new P.NonVisualGroupShapeDrawingProperties(),new P.ApplicationNonVisualDrawingProperties()),new P.GroupShapeProperties(new D.TransformGroup()))));var tree=slide.Slide.CommonSlideData!.ShapeTree!;tree.Append(TextBox(2,"Title",Brand.Name+" Platform Brief",500000,500000,11000000,900000,3200,Brand.DeepBlue));tree.Append(TextBox(3,"Subtitle","Windows Document Architecture\nWord • Excel • PowerPoint",500000,1800000,11000000,1800000,2200,Brand.Graphite));tree.Append(TextBox(4,"Tagline",Brand.Tagline,500000,4500000,11000000,700000,1800,Brand.Silver));pp.Presentation.Append(new P.SlideMasterIdList(new P.SlideMasterId{Id=2147483648,RelationshipId=pp.GetIdOfPart(master)}),new P.SlideIdList(new P.SlideId{Id=256,RelationshipId=pp.GetIdOfPart(slide)}),new P.SlideSize{Cx=12192000,Cy=6858000,Type=P.SlideSizeValues.Screen16x9},new P.NotesSize{Cx=6858000,Cy=9144000});pp.Presentation.Save();}
  static P.Shape TextBox(uint id,string name,string text,long x,long y,long cx,long cy,int size,string color){var shape=new P.Shape(new P.NonVisualShapeProperties(new P.NonVisualDrawingProperties{Id=id,Name=name},new P.NonVisualShapeDrawingProperties(new D.ShapeLocks{NoGrouping=true}),new P.ApplicationNonVisualDrawingProperties()),new P.ShapeProperties(new D.Transform2D(new D.Offset{X=x,Y=y},new D.Extents{Cx=cx,Cy=cy}),new D.PresetGeometry(new D.AdjustValueList()){Preset=D.ShapeTypeValues.Rectangle}),new P.TextBody(new D.BodyProperties(),new D.ListStyle(),new D.Paragraph(new D.Run(new D.RunProperties{Language="en-US",FontSize=size},new D.Text(text)),new D.EndParagraphRunProperties{Language="en-US"})));return shape;}
}
