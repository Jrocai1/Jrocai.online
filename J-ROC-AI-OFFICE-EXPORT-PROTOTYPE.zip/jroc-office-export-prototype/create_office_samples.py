from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, Reference
from openpyxl.worksheet.table import Table, TableStyleInfo
from pathlib import Path

ROOT=Path('/mnt/data/jroc-office-export-prototype')
EXP=ROOT/'exports'; EXP.mkdir(exist_ok=True)
BLUE='00B3FF'; GRAPH='0B0F14'; DEEP='0071FF'; SILVER='C0C6D4'; WHITE='FFFFFF'; SURFACE='111923'

def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); tcPr.append(shd)

def set_margins(section):
    section.top_margin=Inches(.7); section.bottom_margin=Inches(.7); section.left_margin=Inches(.8); section.right_margin=Inches(.8)

def add_title(doc,title,subtitle):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run('J-ROC AI'); r.bold=True; r.font.size=Pt(30); r.font.color.rgb=RGBColor.from_string(DEEP); r.font.name='Montserrat'
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run(title); r.bold=True; r.font.size=Pt(22); r.font.name='Montserrat'; r.font.color.rgb=RGBColor.from_string(GRAPH)
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run(subtitle); r.font.size=Pt(11); r.font.name='Roboto'; r.font.color.rgb=RGBColor.from_string('6B7280')
    doc.add_paragraph()

def create_word():
    doc=Document(); set_margins(doc.sections[0])
    styles=doc.styles
    styles['Normal'].font.name='Roboto'; styles['Normal'].font.size=Pt(10.5)
    for name,size in [('Title',30),('Heading 1',18),('Heading 2',13)]:
        styles[name].font.name='Montserrat'; styles[name].font.size=Pt(size); styles[name].font.color.rgb=RGBColor.from_string(DEEP)
    add_title(doc,'Windows Document Architecture','Word, Excel, and PowerPoint export service | Prototype specification')
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run('ONE BRAND. ONE ECOSYSTEM.'); r.bold=True; r.font.name='Montserrat'; r.font.color.rgb=RGBColor.from_string(BLUE)
    doc.add_page_break()
    doc.add_heading('1. Purpose',level=1)
    doc.add_paragraph('Provide a shared document export service for J-ROC AI Windows and web applications. The service produces Microsoft Word documents, Microsoft Excel workbooks, and Microsoft PowerPoint presentations using modern Office Open XML formats.')
    doc.add_heading('2. Architecture',level=1)
    steps=[('1','Application','Submits an export request with data, template, format, tenant, and product identity.'),('2','Policy layer','Checks permissions, tenant ownership, sensitivity, and approval requirements.'),('3','Brand resolver','Applies approved J-ROC AI colors, typography, product name, metadata, header, and footer.'),('4','Renderer','Creates the selected Word, Excel, or PowerPoint file.'),('5','Output service','Stores the file temporarily, records the audit event, and returns a download or Open action.')]
    table=doc.add_table(rows=1,cols=3); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.autofit=False
    widths=[.55,1.55,4.75]
    hdr=table.rows[0].cells
    for i,t in enumerate(['Step','Component','Responsibility']): hdr[i].text=t; shade(hdr[i],GRAPH); hdr[i].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER; hdr[i].paragraphs[0].runs[0].font.color.rgb=RGBColor.from_string(WHITE); hdr[i].paragraphs[0].runs[0].bold=True
    for step,comp,desc in steps:
        cells=table.add_row().cells
        for i,val in enumerate([step,comp,desc]): cells[i].text=val; cells[i].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for row in table.rows:
        for i,c in enumerate(row.cells): c.width=Inches(widths[i])
    doc.add_heading('3. Shared contract',level=1)
    lines=['ExportRequest','- Document format and template identifier','- Tenant, user, product, and application identifiers','- Structured data payload','- Sensitivity and distribution policy','- Output name and destination','- Required owner approval state']
    for line in lines: doc.add_paragraph(line,style='List Bullet' if line.startswith('-') else None)
    doc.add_heading('4. Format responsibilities',level=1)
    table=doc.add_table(rows=1,cols=3); table.alignment=WD_TABLE_ALIGNMENT.CENTER
    for i,t in enumerate(['Format','Primary use','Examples']): table.rows[0].cells[i].text=t; shade(table.rows[0].cells[i],DEEP); table.rows[0].cells[i].paragraphs[0].runs[0].font.color.rgb=RGBColor.from_string(WHITE); table.rows[0].cells[i].paragraphs[0].runs[0].bold=True
    for row in [('Word','Narrative and formal documents','Reports, proposals, plans, manuals'),('Excel','Structured data and calculations','Inventory, schedules, analytics, models'),('PowerPoint','Visual communication','Executive briefings, training, sales decks')]:
        cells=table.add_row().cells
        for i,v in enumerate(row): cells[i].text=v
    doc.add_heading('5. Security and release controls',level=1)
    for item in ['No macros by default.','Never store platform secrets inside generated documents.','Enforce tenant-scoped authorization before export.','Require owner approval for configured sensitive or external distributions.','Use short-lived temporary storage and deterministic deletion.','Record export metadata, status, hash, and approval in the audit log.','Block release when required J-ROC AI production brand assets are unavailable.']:
        doc.add_paragraph(item,style='List Bullet')
    doc.add_heading('6. Windows integration',level=1)
    doc.add_paragraph('Windows applications expose Create document, Save As, Open in Microsoft Word, Open in Microsoft Excel, and Open in Microsoft PowerPoint actions where appropriate. Web applications use the same backend interface and return secure downloads.')
    sec=doc.sections[0]; footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER; rr=footer.add_run('J-ROC AI | ONE BRAND. ONE ECOSYSTEM.'); rr.font.name='Roboto'; rr.font.size=Pt(8); rr.font.color.rgb=RGBColor.from_string('6B7280')
    path=EXP/'J-ROC-AI-Windows-Document-Architecture.docx'; doc.save(path)
    return path

def create_excel():
    wb=Workbook(); ws=wb.active; ws.title='Export Registry'; ws.sheet_view.showGridLines=False
    ws.merge_cells('A1:H1'); ws['A1']='J-ROC AI Office Export Registry'; ws['A1'].font=Font(name='Montserrat',size=20,bold=True,color=WHITE); ws['A1'].fill=PatternFill('solid',fgColor=GRAPH); ws['A1'].alignment=Alignment(horizontal='left',vertical='center'); ws.row_dimensions[1].height=34
    ws.merge_cells('A2:H2'); ws['A2']='ONE BRAND. ONE ECOSYSTEM.'; ws['A2'].font=Font(name='Roboto',size=10,bold=True,color=BLUE); ws['A2'].fill=PatternFill('solid',fgColor=GRAPH)
    headers=['Export ID','Application','Format','Template','Status','Created Date','Owner Approval','Output File']
    for c,h in enumerate(headers,1): cell=ws.cell(4,c,h); cell.font=Font(bold=True,color=WHITE); cell.fill=PatternFill('solid',fgColor=DEEP); cell.alignment=Alignment(horizontal='center')
    rows=[['EXP-001','Chairman Office','Word','Executive Report','Complete','2026-10-21','Required','Executive-Report.docx'],['EXP-002','Business Analytics','Excel','Operations Workbook','Complete','2026-10-21','Not required','Operations.xlsx'],['EXP-003','Academy','PowerPoint','Training Brief','Complete','2026-10-21','Required','Training-Brief.pptx'],['EXP-004','Repair Suite','Word','Diagnostic Report','Planned','2026-10-21','Required','Diagnostic-Report.docx']]
    for r,row in enumerate(rows,5):
        for c,v in enumerate(row,1): ws.cell(r,c,v); ws.cell(r,c).alignment=Alignment(vertical='center')
    tab=Table(displayName='OfficeExports',ref=f'A4:H{4+len(rows)}'); tab.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True,showColumnStripes=False); ws.add_table(tab)
    widths=[14,24,14,22,15,16,18,28]
    for i,w in enumerate(widths,1): ws.column_dimensions[chr(64+i)].width=w
    ws.freeze_panes='A5'
    met=wb.create_sheet('Format Metrics'); met.sheet_view.showGridLines=False
    met.append(['Format','Exports']); met.append(['Word',2]); met.append(['Excel',1]); met.append(['PowerPoint',1])
    for cell in met[1]: cell.font=Font(bold=True,color=WHITE); cell.fill=PatternFill('solid',fgColor=GRAPH)
    chart=BarChart(); chart.title='Exports by Format'; chart.y_axis.title='Count'; chart.x_axis.title='Format'; chart.add_data(Reference(met,min_col=2,min_row=1,max_row=4),titles_from_data=True); chart.set_categories(Reference(met,min_col=1,min_row=2,max_row=4)); chart.height=7; chart.width=12; met.add_chart(chart,'D2')
    met.column_dimensions['A'].width=20; met.column_dimensions['B'].width=12
    path=EXP/'J-ROC-AI-Office-Export-Registry.xlsx'; wb.save(path)
    load_workbook(path)
    return path

if __name__=='__main__':
    print(create_word()); print(create_excel())
