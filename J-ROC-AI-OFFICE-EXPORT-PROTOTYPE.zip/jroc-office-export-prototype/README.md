# J-ROC AI Office Export Prototype

A Windows-oriented .NET prototype using the Microsoft Open XML SDK to create Word, Excel, and PowerPoint files without automating desktop Office applications.

## Build and run
```powershell
cd src\Jroc.OfficeExport
dotnet restore
dotnet run -- ..\..\exports
```

The `exports` folder receives `.docx`, `.xlsx`, and `.pptx` files.
