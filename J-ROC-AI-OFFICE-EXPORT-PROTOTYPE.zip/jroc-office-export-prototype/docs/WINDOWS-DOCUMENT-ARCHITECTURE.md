# J-ROC AI Windows Document Architecture

## Purpose
Provide one shared document service for J-ROC AI Windows and web applications. The service creates modern Microsoft Office Open XML files: Word `.docx`, Excel `.xlsx`, and PowerPoint `.pptx`.

## Components
1. **Export Request Contract**: product name, document type, template, data, user, tenant, output destination, sensitivity, and approval state.
2. **Permission and Policy Layer**: verifies user permissions, tenant ownership, export policy, and approval for sensitive external distribution.
3. **Brand Resolver**: applies J-ROC AI product identity, approved assets, colors, typography, metadata, headers, footers, and document properties.
4. **Template Registry**: approved Word, Excel, and PowerPoint templates, each versioned and testable.
5. **Format Renderers**: Word report renderer, Excel workbook renderer, and PowerPoint presentation renderer.
6. **Output Service**: secure temporary file creation, malware scan hook, storage, download response, retention, and deletion.
7. **Audit Service**: records requester, product, template, format, destination, result, hash, and approval.
8. **Windows Integration**: file association/open action, Save As, recent exports, and Open in Microsoft Office.

## Request Flow
Application → Export Contract → Permission Check → Brand Resolver → Template Registry → Format Renderer → Validation → Audit → Download/Open.

## Shared Interface
```csharp
public interface IOfficeDocumentExporter
{
    Task<ExportResult> ExportAsync(ExportRequest request, CancellationToken cancellationToken);
}
```

## Format Selection
- Word: narrative reports, proposals, contracts, plans, instructions, and documentation.
- Excel: tables, inventory, schedules, analytics, calculations, imports, and exports.
- PowerPoint: executive briefings, sales presentations, lessons, training, and project updates.

## Security
- No macros by default.
- Do not store secrets inside Office documents.
- Tenant-scoped access checks are mandatory.
- External distribution can require owner approval.
- Temporary files receive short retention and deterministic deletion.
- Audit records store hashes and metadata rather than document contents where practical.

## Branding
Every renderer uses the shared J-ROC AI brand package. Export fails closed if approved production logo assets are required but unavailable. Text-only brand identity may be used only when explicitly allowed by the document policy.
