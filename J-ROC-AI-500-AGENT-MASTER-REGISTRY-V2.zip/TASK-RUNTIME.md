# Task Runtime

J-ROC AI assigns each task with an objective, scope, edition, environment, required inputs, deliverables, dependencies, acceptance tests, risk, approval state, and evidence requirements. Agents may delegate only inside their approved scope and must preserve the parent task authorization. Production changes remain approval-gated.

The included 500 tasks are registry/bootstrap tasks, one for every agent. They are queued definitions for the J-ROC runtime, not claims that external work has already been executed.
