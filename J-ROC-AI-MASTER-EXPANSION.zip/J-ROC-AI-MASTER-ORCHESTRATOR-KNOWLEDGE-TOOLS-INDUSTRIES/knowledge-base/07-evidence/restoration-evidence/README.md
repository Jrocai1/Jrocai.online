# Restoration Evidence

## Purpose
Approved knowledge for this domain.

## Required metadata
- Owner
- Source class
- Source reference
- Review date
- Data classification
- Edition scope
- Status

## Content rules
Facts that can change must be refreshed from authoritative sources. Unverified content cannot drive consequential actions.
