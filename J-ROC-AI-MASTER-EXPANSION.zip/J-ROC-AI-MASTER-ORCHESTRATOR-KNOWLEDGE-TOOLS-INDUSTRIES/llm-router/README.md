# J-ROC AI Quota-Aware Model Router

This design does not promise unlimited hosted free inference. Free tiers are provider-controlled, rate-limited, and changeable. The router uses local models first when configured, then eligible enabled free-tier providers. It never creates extra accounts, bypasses limits, rotates identities, or violates provider terms. When no eligible provider is available, the request is queued, deferred, or returned as blocked. Paid fallback is disabled by default.
