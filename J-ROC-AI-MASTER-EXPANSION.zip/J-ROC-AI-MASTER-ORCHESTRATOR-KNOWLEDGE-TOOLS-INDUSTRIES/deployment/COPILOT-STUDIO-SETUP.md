# Configure the J-ROC AI Main Platform Orchestrator in Microsoft Copilot Studio

1. Create and independently test the specialist agents first.
2. Create a new agent named **J-ROC AI Main Platform Orchestrator**.
3. Copy the description from `agent/agent.json`.
4. Copy `agent/INSTRUCTIONS.md` into the Instructions section.
5. Add the routing catalog and approved J-ROC AI project documents as knowledge.
6. Add specialist agents as connected agents in department-sized groups rather than connecting all 100 at once.
7. Write clear connected-agent descriptions so routing is unambiguous.
8. Configure context inclusion deliberately and pass only necessary context.
9. Add approval flows for consequential operations.
10. Test correct routing, refusal, missing evidence, conflicting results, approval, and release-gate scenarios before publishing.

## Recommended connected groups

- Production Foundation Group
- Data and Security Group
- Frontend and Experience Group
- Backend and Shared Services Group
- Quality Engineering Group
- Windows Engineering Group
- Academy Group
- Commerce Group
- Repair Group
- Marketing, Sales, and Customer Group
- Analytics Group
- Infrastructure and Operations Group
- Application Factory Group
