# Complete Tool Permission Policy

Values: ALLOW means the agent may use the tool within assigned scope; APPROVAL means explicit human approval is required for the exact action; DENY means the tool must not be attached or invoked. Read access does not imply write access. Connected-agent delegation never expands authority. Production and customer-impacting tools must be separate from development tools. Every consequential call must be auditable and idempotent where applicable.
