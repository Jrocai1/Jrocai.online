# J-ROC AI Main Platform Orchestrator Tool Policy

## Recommended tool families

1. **Knowledge retrieval**
   - Approved SharePoint and OneDrive libraries
   - Approved websites and documentation
   - Dataverse or governed business data sources
   - Search and retrieval services exposed through approved connectors

2. **Development and delivery**
   - GitHub repository, issue, pull-request, and approved workflow connectors when configured
   - Staging-only J-ROC AI application programming interfaces
   - Build, test, security-scan, artifact, and deployment status tools
   - Container registry and release metadata tools

3. **Business workflows**
   - Power Automate approval flows
   - Microsoft Planner work tracking
   - Approved customer relationship management, inventory, service, and commerce connectors

4. **Microsoft 365 productivity**
   - Word, Excel, and PowerPoint document workflows
   - Outlook/Teams/SharePoint actions only when needed, authorized, and connected

5. **Agent extensibility**
   - Connected specialist agents
   - Agent flows for deterministic multi-step work
   - AI prompts for narrowly structured transformations
   - Model Context Protocol servers for authenticated tools/data when approved
   - Computer-use automation only for approved interfaces where safer deterministic interfaces are unavailable

## Permission model
- Read-only tools by default.
- Separate tools by development, testing, staging, and production environment.
- Never attach a highly privileged tool merely because one specialist may occasionally need it.
- Consequential write actions require explicit approval and must be narrowly scoped.
- Connected agents never expand the parent agent's authority.
- Production secrets are never knowledge sources.
- Tool calls must carry verified edition, user, organization, application, entitlement, and approval context when applicable.
