# Validation

Validate: permission matrix completeness; 25 industry agents; knowledge manifest paths; no production-write ALLOW for Main Orchestrator; free-tier router never claims unlimited and denies when no eligible provider exists.
