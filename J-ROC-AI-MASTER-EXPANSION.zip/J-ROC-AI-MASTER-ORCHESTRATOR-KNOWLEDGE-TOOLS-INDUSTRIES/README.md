# J-ROC AI Main Platform Orchestrator

This is the parent command agent for the 100-agent J-ROC AI development workforce. It plans, delegates, tracks, validates, requests approval, and consolidates results. It does not bypass specialist permissions or release gates.

Start with `deployment/COPILOT-STUDIO-SETUP.md`.
