# J-ROC AI Authoritative Brand System

This package provides authoritative tokens, metadata, shared CSS, JAF/JAAF gates, injection logic, and a branding audit CLI.

The production logo remains intentionally blocked because no previously approved official logo asset was found. The generated brand board is stored only as a concept reference. Add Chairman-approved production assets at the paths in `brand-manifest.json`; never rename a temporary image to bypass validation.

## Audit an existing application
`node bin/jroc-brand-audit.js /path/to/app`

## Inject brand foundation
`node bin/jroc-brand-inject.js /path/to/app`

## JAF gate
`node factories/jaf/brand-gate.js /path/to/app`

## JAAF gate
`node factories/jaaf/brand-gate.js /path/to/app`

A nonzero exit code blocks CI/release.
