#!/usr/bin/env node
import path from 'node:path';import {runGate} from '../gate-lib.js';const target=path.resolve(process.argv[2]||'.'),result=runGate('JAF',target);console.log(JSON.stringify(result,null,2));process.exitCode=result.releaseStatus==='ALLOWED'?0:3;
