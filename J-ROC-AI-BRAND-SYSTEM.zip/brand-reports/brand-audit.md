# J-ROC Branding Audit

Status: **BLOCKED**
Release allowed: **NO**
Passed: 14/20

- FAIL asset:public/brand/jroc-ai-primary.svg: public/brand/jroc-ai-primary.svg
- FAIL asset:public/brand/app-icon-512.png: public/brand/app-icon-512.png
- FAIL asset:public/brand/favicon.ico: public/brand/favicon.ico
- FAIL manifest: jroc-brand.json
- FAIL css: public/jroc-brand.css
- PASS parent-brand: J-ROC AI parent brand
- PASS color:jroc-blue: #00B3FF
- PASS color:graphite: #0B0F14
- PASS color:deep-blue: #0071FF
- PASS color:silver: #C0C6D4
- PASS font:heading: Montserrat
- PASS font:body: Roboto
- PASS metadata:title: title/displayName
- PASS metadata:theme-color: theme-color
- PASS metadata:icon: favicon/app icon
- PASS ui:header: branded header
- PASS ui:footer: branded footer
- PASS responsive: responsive CSS
- PASS focus: focus-visible
- FAIL no-fake-assets: no placeholder/fake asset markers