# Production Asset Approval

The generated brand board in `assets/reference` is a concept reference only. It is not the production logo package and is intentionally excluded from required asset paths.

Chairman-level approval must place final source-controlled files at the exact required paths in `assets/logo`, `assets/icons`, and `assets/favicon`. The logo files must not be renamed placeholders or exports from an unapproved concept. Until all required files exist, both factory gates must return `BLOCKED`.
