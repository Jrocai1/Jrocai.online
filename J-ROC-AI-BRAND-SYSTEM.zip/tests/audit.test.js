import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {auditProject} from '../validators/audit-lib.js';
const make=()=>fs.mkdtempSync(path.join(os.tmpdir(),'jroc-brand-'));
test('blocks an unbranded application',()=>{const d=make();fs.writeFileSync(path.join(d,'index.html'),'<title>App</title>');assert.equal(auditProject(d).status,'BLOCKED')});
test('requires production assets',()=>{const d=make();fs.mkdirSync(path.join(d,'public'),{recursive:true});fs.writeFileSync(path.join(d,'public','jroc-brand.css'),':root{--x:#00B3FF}');fs.writeFileSync(path.join(d,'jroc-brand.json'),'{}');assert.equal(auditProject(d).checks.find(x=>x.id.includes('primary.svg')).pass,false)});
test('rejects placeholder asset markers',()=>{const d=make();fs.writeFileSync(path.join(d,'app.js'),'const x="placeholder-logo"');assert.equal(auditProject(d).checks.find(x=>x.id==='no-fake-assets').pass,false)});
