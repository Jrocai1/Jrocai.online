import fs from 'node:fs';import path from 'node:path';
const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):'';
const walk=(dir,out=[])=>{if(!fs.existsSync(dir))return out;for(const n of fs.readdirSync(dir)){if(['node_modules','.git','dist','build'].includes(n))continue;const p=path.join(dir,n),s=fs.statSync(p);s.isDirectory()?walk(p,out):out.push(p)}return out};
const rel=(root,p)=>path.relative(root,p).replaceAll('\\','/');
export function auditProject(root,options={}){root=path.resolve(root);const files=walk(root);const textFiles=files.filter(f=>/\.(html|css|js|jsx|ts|tsx|json|md)$/.test(f));const all=textFiles.map(read).join('\n');const requiredAssets=options.requiredAssets||['public/brand/jroc-ai-primary.svg','public/brand/app-icon-512.png','public/brand/favicon.ico'];const checks=[];const add=(id,pass,detail,severity='error')=>checks.push({id,pass,detail,severity});
for(const asset of requiredAssets)add(`asset:${asset}`,fs.existsSync(path.join(root,asset)),asset);
add('manifest',fs.existsSync(path.join(root,'jroc-brand.json')),'jroc-brand.json');
add('css',fs.existsSync(path.join(root,'public/jroc-brand.css')),'public/jroc-brand.css');
add('parent-brand',/J-ROC AI/i.test(all),'J-ROC AI parent brand');
add('color:jroc-blue',/#00B3FF/i.test(all),'#00B3FF');add('color:graphite',/#0B0F14/i.test(all),'#0B0F14');add('color:deep-blue',/#0071FF/i.test(all),'#0071FF');add('color:silver',/#C0C6D4/i.test(all),'#C0C6D4');
add('font:heading',/Montserrat/i.test(all),'Montserrat');add('font:body',/Roboto/i.test(all),'Roboto');
add('metadata:title',/<title[^>]*>[^<]*J-ROC AI/i.test(all)||/"displayName"\s*:\s*"J-ROC AI/i.test(all),'title/displayName');
add('metadata:theme-color',/theme-color/i.test(all)||/"themeColor"/i.test(all),'theme-color');add('metadata:icon',/favicon|app-icon/i.test(all),'favicon/app icon');
add('ui:header',/jroc-header|data-jroc-brand/i.test(all),'branded header');add('ui:footer',/jroc-footer/i.test(all),'branded footer');
add('responsive',/@media/i.test(all),'responsive CSS');add('focus',/:focus-visible/i.test(all),'focus-visible');
add('no-fake-assets',!/(placeholder-logo|temporary-logo|random-icon|logo-placeholder)/i.test(all),'no placeholder/fake asset markers');
const failures=checks.filter(x=>!x.pass&&x.severity==='error');return {tool:'J-ROC Branding Audit',root,status:failures.length?'BLOCKED':'PASS',releaseAllowed:failures.length===0,summary:{total:checks.length,passed:checks.filter(x=>x.pass).length,failed:failures.length},checks,scannedFiles:files.map(f=>rel(root,f)),generatedAt:new Date().toISOString()}}
export function formatReport(r){return [`# J-ROC Branding Audit`,``,`Status: **${r.status}**`,`Release allowed: **${r.releaseAllowed?'YES':'NO'}**`,`Passed: ${r.summary.passed}/${r.summary.total}`,``,...r.checks.map(c=>`- ${c.pass?'PASS':'FAIL'} ${c.id}: ${c.detail}`)].join('\n')}
