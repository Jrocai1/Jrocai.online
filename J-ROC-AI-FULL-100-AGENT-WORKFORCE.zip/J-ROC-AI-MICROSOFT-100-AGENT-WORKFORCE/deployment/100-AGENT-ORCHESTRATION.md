# 100-Agent Orchestration Guidance

- The Production Build Coordinator owns production foundation work.
- The Application Factory Agent owns application implementation workflows.
- Division specialists should be connected only to the coordinator that needs them.
- Use child agents for small reusable workflows sharing parent context.
- Use connected agents for domain separation, separate tools, or separate knowledge.
- Give each connected agent clear routing criteria and the minimum context required.
- A parent agent must not gain additional privileges by calling a connected agent.
- Consequential actions require approval regardless of which agent performs them.
- Evaluate each specialist independently before including the specialist in orchestration.
