# J-ROC AI 100-Agent Department Index

- Academy and Learning: 6 agents
- Analytics and Insight: 5 agents
- Backend and Services: 8 agents
- Commerce: 6 agents
- Core Production and Governance: 25 agents
- Data and Database: 7 agents
- Frontend and Experience: 7 agents
- Infrastructure and Platform: 6 agents
- Marketing and Growth: 6 agents
- Quality Engineering: 7 agents
- Repair Solutions: 6 agents
- Sales and Customer: 6 agents
- Windows Engineering: 5 agents
