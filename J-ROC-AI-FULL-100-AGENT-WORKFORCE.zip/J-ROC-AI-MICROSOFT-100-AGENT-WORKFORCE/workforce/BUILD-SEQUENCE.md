# Recommended Build Sequence

1. Core Production and Governance agents.
2. Identity, database, application programming interface security, and tests.
3. Infrastructure, deployment, observability, and recovery.
4. Shared backend, storage, workers, Model Gateway, Office documents, and branding.
5. Private, Business, and Consumer edition experiences.
6. Commerce, Academy, Repair, Marketing, Sales, Support, and Analytics specialists.
7. Application Factory batches with Release Gate review.

Do not connect all 100 agents to one parent by default. Use department coordinators or connected-agent groups and pass only necessary context.
