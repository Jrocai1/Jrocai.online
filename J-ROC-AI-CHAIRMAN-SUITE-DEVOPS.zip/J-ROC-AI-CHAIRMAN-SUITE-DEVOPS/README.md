# J-ROC AI Chairman Suite DevOps

Adds Chairman login, secure server sessions, agent change requests, approval decisions, local Git/repository workspace references, allowlisted lint/test/build commands, and GitHub Actions continuous integration.

## Start
1. Copy `.env.example` to `.env`.
2. Replace the PostgreSQL and Chairman passwords.
3. Set `JROC_WORKSPACE_PATH` to a folder containing authorized local repositories.
4. Run `docker compose up --build -d`.
5. Open `http://localhost:3100` and sign in.

## Security boundary
Only allowlisted package commands (`npm run lint`, `npm test`, `npm run build`) can be launched. Arbitrary shell input is not accepted. Agent change requests create approval records but do not yet generate patches autonomously; connect the approved J-ROC Agent Runtime Adapter to populate proposed patches, create branches/commits, run tests, and submit changes. For internet deployment, enable HTTPS and set `COOKIE_SECURE=true`.
