$ErrorActionPreference = "Stop"
if (-not (Test-Path .env)) { Copy-Item .env.example .env; Write-Host "Created .env. Replace the password and run again."; exit 1 }
docker compose up --build -d
docker compose ps
Start-Process "http://localhost:3100"
