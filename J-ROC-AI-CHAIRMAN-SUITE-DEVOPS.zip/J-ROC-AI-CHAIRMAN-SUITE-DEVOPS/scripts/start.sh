#!/usr/bin/env sh
set -eu
[ -f .env ] || { cp .env.example .env; echo 'Created .env. Replace password and rerun.'; exit 1; }
docker compose up --build -d
