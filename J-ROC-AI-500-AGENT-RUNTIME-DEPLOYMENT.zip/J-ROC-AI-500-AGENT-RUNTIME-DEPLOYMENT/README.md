# J-ROC AI 500-Agent Runtime Deployment

## Start locally
1. Copy `.env.example` to `.env` and replace the password.
2. Run `docker compose config`.
3. Run `docker compose up --build -d --scale worker=3`.
4. Check `docker compose ps` and `http://localhost:3100/health`.

## Important
This is deployment-ready scaffolding for PostgreSQL, the orchestrator API, and concurrent task workers. It is not yet the finished 500-agent production runtime. Provider adapters, authentication, row-level security, agent-tool connectors, artifact storage, telemetry, backups, and full release automation remain required before production.
