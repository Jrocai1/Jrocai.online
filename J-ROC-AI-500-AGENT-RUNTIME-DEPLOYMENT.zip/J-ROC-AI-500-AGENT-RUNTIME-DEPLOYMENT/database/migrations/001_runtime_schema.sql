-- J-ROC AI runtime task database schema for PostgreSQL
create type jroc_task_status as enum ('QUEUED','ASSIGNED','IN_PROGRESS','TESTING','FIX_REQUIRED','BLOCKED','AWAITING_APPROVAL','VALIDATED','COMPLETE','RELEASE_CANDIDATE','RELEASE_READY','DEPLOYED','CANCELLED');
create type jroc_risk_level as enum ('LOW','MEDIUM','HIGH','CRITICAL');
create type jroc_approval_status as enum ('NOT_REQUIRED','PENDING','APPROVED','REJECTED','EXPIRED');

create table agents (
  id text primary key,
  name text not null unique,
  division text not null,
  parent_agent_id text references agents(id),
  status text not null default 'REGISTERED',
  can_receive_tasks boolean not null default true,
  can_delegate_within_scope boolean not null default false,
  final_release_authority boolean not null default false,
  created_at timestamptz not null default now()
);

create table projects (
  id uuid primary key,
  name text not null,
  edition text not null check (edition in ('private','business','consumer','shared')),
  environment text not null check (environment in ('development','test','staging','production')),
  organization_id uuid,
  owner_user_id uuid not null,
  status text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table tasks (
  id uuid primary key,
  project_id uuid not null references projects(id) on delete cascade,
  parent_task_id uuid references tasks(id),
  assigned_agent_id text references agents(id),
  created_by_agent_id text references agents(id),
  title text not null,
  objective text not null,
  edition text not null,
  environment text not null,
  priority smallint not null default 50 check (priority between 0 and 100),
  risk_level jroc_risk_level not null default 'MEDIUM',
  status jroc_task_status not null default 'QUEUED',
  approval_status jroc_approval_status not null default 'NOT_REQUIRED',
  approval_scope text,
  organization_id uuid,
  owner_user_id uuid not null,
  application_id text,
  data_classification text not null default 'internal',
  attempt_count integer not null default 0,
  max_attempts integer not null default 3,
  queued_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table task_inputs (id uuid primary key, task_id uuid not null references tasks(id) on delete cascade, input_type text not null, source_ref text, payload jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());
create table task_dependencies (task_id uuid not null references tasks(id) on delete cascade, depends_on_task_id uuid not null references tasks(id) on delete cascade, dependency_type text not null default 'blocks', primary key(task_id,depends_on_task_id));
create table task_deliverables (id uuid primary key, task_id uuid not null references tasks(id) on delete cascade, name text not null, artifact_ref text, checksum text, status text not null default 'PENDING', created_at timestamptz not null default now());
create table task_acceptance_tests (id uuid primary key, task_id uuid not null references tasks(id) on delete cascade, name text not null, expected_result text not null, actual_result text, status text not null default 'PENDING', evidence_ref text, executed_at timestamptz);
create table task_evidence (id uuid primary key, task_id uuid not null references tasks(id) on delete cascade, evidence_type text not null, evidence_ref text not null, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());
create table task_events (id bigserial primary key, task_id uuid not null references tasks(id) on delete cascade, actor_agent_id text references agents(id), event_type text not null, from_status jroc_task_status, to_status jroc_task_status, details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());
create table approvals (id uuid primary key, task_id uuid not null references tasks(id) on delete cascade, requested_by_agent_id text references agents(id), approval_scope text not null, status jroc_approval_status not null default 'PENDING', approved_by_user_id uuid, requested_at timestamptz not null default now(), decided_at timestamptz, expires_at timestamptz);
create table agent_tool_permissions (agent_id text not null references agents(id) on delete cascade, tool_key text not null, environment text not null, permission text not null check(permission in ('ALLOW','APPROVAL','DENY')), scope jsonb not null default '{}'::jsonb, primary key(agent_id,tool_key,environment));
create table task_leases (task_id uuid primary key references tasks(id) on delete cascade, worker_id text not null, leased_until timestamptz not null, heartbeat_at timestamptz not null default now());

create index tasks_status_priority_idx on tasks(status,priority desc,queued_at);
create index tasks_agent_status_idx on tasks(assigned_agent_id,status);
create index tasks_project_idx on tasks(project_id);
create index tasks_org_idx on tasks(organization_id) where organization_id is not null;
create index events_task_time_idx on task_events(task_id,created_at);

-- Atomic task claim function for concurrent workers.
create or replace function claim_next_task(p_worker_id text, p_lease_seconds integer default 60)
returns tasks language plpgsql as $$
declare claimed tasks;
begin
  select * into claimed from tasks
   where status in ('QUEUED','ASSIGNED','FIX_REQUIRED')
     and attempt_count < max_attempts
     and not exists (
       select 1 from task_dependencies d
       join tasks dep on dep.id=d.depends_on_task_id
       where d.task_id=tasks.id and dep.status not in ('VALIDATED','COMPLETE','RELEASE_READY','DEPLOYED')
     )
   order by priority desc, queued_at asc
   for update skip locked limit 1;
  if claimed.id is null then return null; end if;
  update tasks set status='IN_PROGRESS', started_at=coalesce(started_at,now()), attempt_count=attempt_count+1, updated_at=now() where id=claimed.id returning * into claimed;
  insert into task_leases(task_id,worker_id,leased_until,heartbeat_at)
  values(claimed.id,p_worker_id,now()+make_interval(secs=>p_lease_seconds),now())
  on conflict(task_id) do update set worker_id=excluded.worker_id,leased_until=excluded.leased_until,heartbeat_at=now();
  insert into task_events(task_id,actor_agent_id,event_type,to_status,details) values(claimed.id,claimed.assigned_agent_id,'TASK_CLAIMED','IN_PROGRESS',jsonb_build_object('workerId',p_worker_id));
  return claimed;
end $$;
