# J-ROC AI Worker Architecture

1. Main Platform Orchestrator receives an objective and creates typed tasks.
2. PostgreSQL stores tasks, dependencies, approvals, leases, artifacts, tests, evidence, and events.
3. Concurrent workers call `claim_next_task`; `FOR UPDATE SKIP LOCKED` prevents waiting on already-claimed rows.
4. The worker enforces edition, environment, tenant, risk, approval, and tool-permission context before agent invocation.
5. The assigned specialist returns artifacts and evidence.
6. Testing agents evaluate acceptance tests and send failures back as `FIX_REQUIRED`.
7. Release Gate reviews validated release candidates.
8. Explicit approval is required for consequential production actions.

This starter worker moves a task to `TESTING` after the runtime adapter point. Actual connected-agent invocation, artifact storage, and specialist result validation still need implementation.
