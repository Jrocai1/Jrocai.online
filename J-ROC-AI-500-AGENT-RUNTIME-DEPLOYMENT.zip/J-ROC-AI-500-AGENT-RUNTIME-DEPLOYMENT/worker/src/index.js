import pg from 'pg';
const pool=new pg.Pool({connectionString:process.env.DATABASE_URL});
const workerId=process.env.WORKER_ID||`worker-${process.pid}`;
const interval=Math.max(1000,Number(process.env.POLL_INTERVAL_MS||3000));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function claim(){const c=await pool.connect();try{await c.query('begin');const q=await c.query('select (claim_next_task($1,$2)).*',[workerId,60]);await c.query('commit');return q.rows[0]||null}catch(e){await c.query('rollback');throw e}finally{c.release()}}
async function complete(task,status,details={}){await pool.query('update tasks set status=$2,completed_at=case when $2 in (\'COMPLETE\',\'VALIDATED\') then now() else completed_at end,updated_at=now() where id=$1',[task.id,status]);await pool.query('insert into task_events(task_id,actor_agent_id,event_type,to_status,details) values($1,$2,$3,$4,$5)',[task.id,task.assigned_agent_id,'WORKER_RESULT',status,details]);await pool.query('delete from task_leases where task_id=$1',[task.id])}
async function execute(task){if(['HIGH','CRITICAL'].includes(task.risk_level)&&task.approval_status!=='APPROVED'&&task.environment==='production'){await complete(task,'AWAITING_APPROVAL',{reason:'production high-risk approval required'});return}await complete(task,'TESTING',{message:'runtime adapter must invoke assigned agent and persist artifacts/evidence'})}
for(;;){try{const task=await claim();if(task)await execute(task);else await sleep(interval)}catch(e){console.error(e);await sleep(interval)}}
