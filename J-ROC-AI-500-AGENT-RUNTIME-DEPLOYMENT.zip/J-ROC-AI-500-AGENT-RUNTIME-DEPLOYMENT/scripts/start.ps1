$ErrorActionPreference = "Stop"
if (-not (Test-Path .env)) { Copy-Item .env.example .env; Write-Host "Created .env. Replace the database password, then run this script again."; exit 1 }
docker compose up --build -d --scale worker=3
docker compose ps
