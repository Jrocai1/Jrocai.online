#!/usr/bin/env sh
set -eu
[ -f .env ] || { cp .env.example .env; echo 'Created .env. Replace the database password, then rerun.'; exit 1; }
docker compose up --build -d --scale worker=3
docker compose ps
