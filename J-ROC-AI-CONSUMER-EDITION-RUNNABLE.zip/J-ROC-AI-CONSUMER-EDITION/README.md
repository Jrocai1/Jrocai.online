# J-ROC AI Consumer Edition

## Local start
```powershell
Copy-Item .env.example .env
.\Start-Local.ps1
```
Open `http://localhost:3103`.

## Docker start
```powershell
Copy-Item .env.example .env
.\Start-Docker.ps1
```

Authentication uses scrypt password hashing and opaque two-hour bearer sessions. The default commercial billing mode is local development mode and never charges money. To use Stripe test mode, set `BILLING_MODE=stripe`, add test secrets and price identifiers, then forward signed webhook events to `/api/webhooks/stripe`. Never use live keys until webhook tests and entitlement tests pass.
