# J-ROC AI Agent Runtime Adapter

Flow: Chairman requests change → coding agent provider proposes complete replacement file contents → proposal stored/versioned → Chairman approves → repository must be clean and inside `/workspace` → J-ROC creates a change branch → applies only safe relative file paths → runs lint, tests, then build → commits only after checks pass → optional pull request endpoint uses configured GitHub token.

This adapter uses an OpenAI-compatible chat endpoint, which can point at local Ollama. It does not accept arbitrary shell commands. It does not merge or deploy automatically. Pull-request creation is a separate authenticated action.
