alter table code_change_requests add column if not exists model_provider text;
alter table code_change_requests add column if not exists model_name text;
alter table code_change_requests add column if not exists result_summary text;
alter table code_change_requests add column if not exists test_status text;
alter table code_change_requests add column if not exists commit_sha text;
alter table code_change_requests add column if not exists applied_at timestamptz;
create table if not exists agent_runs (id uuid primary key, change_request_id uuid not null references code_change_requests(id) on delete cascade, agent_id text, status text not null, provider text, model text, input_summary text, output_summary text, started_at timestamptz default now(), completed_at timestamptz);
create table if not exists git_operations (id bigserial primary key, workspace_id uuid not null references application_workspaces(id) on delete cascade, change_request_id uuid references code_change_requests(id), operation text not null, branch_name text, commit_sha text, status text not null, output text, created_at timestamptz default now());
